/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Admin;

import Edu.esprit.Entities.fichepfe;
import java.io.IOException;
import java.lang.reflect.InvocationTargetException;
import java.net.URL;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.Arrays;
import java.util.Collections;
import java.util.ResourceBundle;
import javafx.application.Platform;
import javafx.beans.value.ChangeListener;
import javafx.beans.value.ObservableValue;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableColumn.CellEditEvent;
import javafx.scene.control.TableView;
import javafx.scene.control.TextField;
import javafx.scene.control.ToggleButton;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.control.cell.TextFieldTableCell;
import javafx.scene.media.Media;
import javafx.scene.media.MediaPlayer;
import javafx.stage.Stage;
import Utils.DbConnection;
import service.CrudPfe;

/**
 * FXML Controller class
 *
 * @author Talel
 */
public class ListeFichesController implements Initializable {

    @FXML
    private TableColumn<fichepfe, String> nomC;
    @FXML
    private TableColumn<fichepfe, String> prenomC;
    @FXML
    private TableColumn<fichepfe, String> sujetC;
    @FXML
    private TableColumn<fichepfe, String> fonctionnalitesC;
    @FXML
    private TableColumn<fichepfe, String> technologiesC;
    @FXML
    private TableColumn<fichepfe, Integer> etatC;
    @FXML
    private TableColumn<fichepfe, String> etablissementC;

    private DbConnection dc;
    boolean selected = false;

    private ObservableList<fichepfe> data = FXCollections.observableArrayList();

    @FXML
    private TableView<fichepfe> tableFiches;
    @FXML
    private Button btnAfficher;
    @FXML
    private TableColumn<fichepfe, Integer> idC;
    @FXML
    private Button delBtn;
    private int id;
    @FXML
    private Button btnArchives;

    @FXML
    private TextField filterField;
    @FXML
    private Button closeBtn;
    @FXML
    private Button btnDesarchiver;
    @FXML
    private ToggleButton pauseBtn;

    /**
     * Initializes the controller class.
     *
     * @param url
     * @param rb
     * @throws java.lang.reflect.InvocationTargetException
     */
    @Override
    public void initialize(URL url, ResourceBundle rb) {
        // TODO
        dc = new DbConnection();
        btnDesarchiver.setDisable(true);

         try {
            final URL resource = getClass().getResource("mix.mp3");
            final Media media = new Media(resource.toString());
            final MediaPlayer mediaPlayer = new MediaPlayer(media);
            mediaPlayer.setOnError(new Runnable() {
                @Override
                public void run() {
                    final String errorMessage = media.getError().getMessage();
                }
            });
            mediaPlayer.play();
            
            
            pauseBtn.setOnAction(event -> {
    if (pauseBtn.isSelected()) {
        mediaPlayer.pause();
    }else {
        mediaPlayer.play();
    }
});

        } catch (RuntimeException re) {
            System.out.println("Error" + re);
        }
         
         
        afficher();

        filterField.textProperty().addListener(new ChangeListener() {
            @Override
            public void changed(ObservableValue observable, Object oldValue, Object newValue) {
                filtrerFicheList((String) oldValue, (String) newValue);
            }

        });

        tableFiches.setEditable(true);
        nomC.setCellFactory(TextFieldTableCell.<fichepfe>forTableColumn());
        prenomC.setCellFactory(TextFieldTableCell.<fichepfe>forTableColumn());
        sujetC.setCellFactory(TextFieldTableCell.<fichepfe>forTableColumn());
        fonctionnalitesC.setCellFactory(TextFieldTableCell.<fichepfe>forTableColumn());
        technologiesC.setCellFactory(TextFieldTableCell.<fichepfe>forTableColumn());
        etablissementC.setCellFactory(TextFieldTableCell.<fichepfe>forTableColumn());
        nomC.setOnEditCommit(
                new EventHandler<CellEditEvent<fichepfe, String>>() {
            @Override
            public void handle(CellEditEvent<fichepfe, String> t) {
                ((fichepfe) t.getTableView().getItems().get(t.getTablePosition().getRow())).setNom(t.getNewValue());
                String newName = t.getNewValue();
                int ID = t.getRowValue().getId(); //Unique identfier is something that uniquely identify the row. It could be the name of the object that we are pricing here.
                fichepfe p = new fichepfe(ID, newName, t.getRowValue().getPrenom(), t.getRowValue().getSujet(), t.getRowValue().getFonctionnalites(), t.getRowValue().getTechnologies(), t.getRowValue().getEtat(), t.getRowValue().getEtablissement(), t.getRowValue().getIduser());
                CrudPfe.updateUserByID(p, ID); //Call DAO now
            }
        }
        );

        prenomC.setOnEditCommit(
                new EventHandler<CellEditEvent<fichepfe, String>>() {
            @Override
            public void handle(CellEditEvent<fichepfe, String> t) {
                ((fichepfe) t.getTableView().getItems().get(t.getTablePosition().getRow())).setPrenom(t.getNewValue());
                String newPren = t.getNewValue();
                int ID = t.getRowValue().getId(); //Unique identfier is something that uniquely identify the row. It could be the name of the object that we are pricing here.
                fichepfe p = new fichepfe(ID, t.getRowValue().getNom(), newPren, t.getRowValue().getSujet(), t.getRowValue().getFonctionnalites(), t.getRowValue().getTechnologies(), t.getRowValue().getEtat(), t.getRowValue().getEtablissement(), t.getRowValue().getIduser());
                CrudPfe.updateUserByID(p, ID); //Call DAO now
            }
        }
        );

        sujetC.setOnEditCommit(
                new EventHandler<CellEditEvent<fichepfe, String>>() {
            @Override
            public void handle(CellEditEvent<fichepfe, String> t) {
                ((fichepfe) t.getTableView().getItems().get(t.getTablePosition().getRow())).setSujet(t.getNewValue());
                String newSuj = t.getNewValue();
                int ID = t.getRowValue().getId(); //Unique identfier is something that uniquely identify the row. It could be the name of the object that we are pricing here.
                fichepfe p = new fichepfe(ID, t.getRowValue().getNom(), t.getRowValue().getPrenom(), newSuj, t.getRowValue().getFonctionnalites(), t.getRowValue().getTechnologies(), t.getRowValue().getEtat(), t.getRowValue().getEtablissement(), t.getRowValue().getIduser());
                CrudPfe.updateUserByID(p, ID); //Call DAO now
            }
        }
        );

        fonctionnalitesC.setOnEditCommit(
                new EventHandler<CellEditEvent<fichepfe, String>>() {
            @Override
            public void handle(CellEditEvent<fichepfe, String> t) {
                ((fichepfe) t.getTableView().getItems().get(t.getTablePosition().getRow())).setFonctionnalites(t.getNewValue());
                String newFonc = t.getNewValue();
                int ID = t.getRowValue().getId(); //Unique identfier is something that uniquely identify the row. It could be the name of the object that we are pricing here.
                fichepfe p = new fichepfe(ID, t.getRowValue().getNom(), t.getRowValue().getPrenom(), t.getRowValue().getSujet(), newFonc, t.getRowValue().getTechnologies(), t.getRowValue().getEtat(), t.getRowValue().getEtablissement(), t.getRowValue().getIduser());
                CrudPfe.updateUserByID(p, ID); //Call DAO now
            }
        }
        );

        technologiesC.setOnEditCommit(
                new EventHandler<CellEditEvent<fichepfe, String>>() {
            @Override
            public void handle(CellEditEvent<fichepfe, String> t) {
                ((fichepfe) t.getTableView().getItems().get(t.getTablePosition().getRow())).setTechnologies(t.getNewValue());
                String newTech = t.getNewValue();
                int ID = t.getRowValue().getId(); //Unique identfier is something that uniquely identify the row. It could be the name of the object that we are pricing here.
                fichepfe p = new fichepfe(ID, t.getRowValue().getNom(), t.getRowValue().getPrenom(), t.getRowValue().getSujet(), t.getRowValue().getFonctionnalites(), newTech, t.getRowValue().getEtat(), t.getRowValue().getEtablissement(), t.getRowValue().getIduser());
                CrudPfe.updateUserByID(p, ID); //Call DAO now
            }
        }
        );

        etablissementC.setOnEditCommit(
                new EventHandler<CellEditEvent<fichepfe, String>>() {
            @Override
            public void handle(CellEditEvent<fichepfe, String> t) {
                ((fichepfe) t.getTableView().getItems().get(t.getTablePosition().getRow())).setTechnologies(t.getNewValue());
                int ID = t.getRowValue().getId(); //Unique identfier is something that uniquely identify the row. It could be the name of the object that we are pricing here.
                fichepfe p = new fichepfe(ID, t.getRowValue().getNom(), t.getRowValue().getPrenom(), t.getRowValue().getSujet(), t.getRowValue().getFonctionnalites(), t.getRowValue().getTechnologies(), t.getRowValue().getEtat(), t.getNewValue(), t.getRowValue().getIduser());
                CrudPfe.updateUserByID(p, ID); //Call DAO now
            }
        }
        );
    }

// @FXML   
// private void searchAction (ActionEvent event) {
// 
//     private void filteredSearch(){
//     
//     list.clear();
//     
//     for (Annonce a : mylist ) {
//     
//     if (matchesFilter(a)){
//         list.add(a);
//                 }
//     
//     }
//     }
//     
//     rappelerTableSortList();
//     
//     }
//    void filtrerFicheList(String oldValue, String newValue ) {
//        //String choix = comboRech.getValue();
//            ObservableList<fichepfe> filteredList = FXCollections.observableArrayList();
//
//        CrudPfe st = new CrudPfe(); 
//        if (filterField.getText() == null || (newValue.length() < oldValue.length()) || newValue == null) {
//            filteredList.clear();
//            tableFiches.setItems(st.showFiches());
//            filterField.clear();
//        } else {
//
//            newValue = newValue.toUpperCase();
//
//            for (fichepfe f : tableFiches.getItems()) {
//                String filterFicheName = f.getPrenom();
//                if ((filterFicheName.toUpperCase().contains(newValue))) {
//                    filteredList.add(f);
//                }
//                tableFiches.setItems(filteredList);
//                
//            }
//            
//        }
//        
//    }
    @FXML
    private void loadDataFromDatabase(ActionEvent event) {
        try {

            delBtn.setDisable(false);
            btnDesarchiver.setDisable(true);
            Connection conn = dc.Connect();
            data = FXCollections.observableArrayList();
            // Execute query and store result in a resultset
            ResultSet rs = conn.createStatement().executeQuery("SELECT *  FROM fichepfe group by nom,prenom");
            while (rs.next()) {
                //get string from db,whichever way 
                data.add(new fichepfe(rs.getInt(1), rs.getString(2), rs.getString(3), rs.getString(4), rs.getString(5), rs.getString(6), rs.getInt(7), rs.getString(8), rs.getInt(9)));

                data.removeAll(Collections.singleton(null));
                data.removeAll(Arrays.asList("", null));
            }

        } catch (SQLException ex) {
            System.err.println("Error" + ex);
        }

        //Set cell value factory to tableview.
        //NB.PropertyValue Factory must be the same with the one set in model class.
        idC.setCellValueFactory(new PropertyValueFactory<>("id"));
        nomC.setCellValueFactory(new PropertyValueFactory<>("nom"));
        prenomC.setCellValueFactory(new PropertyValueFactory<>("prenom"));
        sujetC.setCellValueFactory(new PropertyValueFactory<>("sujet"));
        fonctionnalitesC.setCellValueFactory(new PropertyValueFactory<>("fonctionnalites"));
        technologiesC.setCellValueFactory(new PropertyValueFactory<>("technologies"));
        etatC.setCellValueFactory(new PropertyValueFactory<>("etat"));
        etablissementC.setCellValueFactory(new PropertyValueFactory<>("etablissement"));
        prenomC.setSortType(TableColumn.SortType.DESCENDING);
        nomC.setSortType(TableColumn.SortType.DESCENDING);
        tableFiches.setItems(null);
        tableFiches.setItems(data);

    }

    public void afficher() {

        try {

            Connection conn = dc.Connect();
            data = FXCollections.observableArrayList();
            // Execute query and store result in a resultset
            ResultSet rs = conn.createStatement().executeQuery("SELECT *  FROM fichepfe group by nom,prenom");
            while (rs.next()) {
                //get string from db,whichever way 
                data.add(new fichepfe(rs.getInt(1), rs.getString(2), rs.getString(3), rs.getString(4), rs.getString(5), rs.getString(6), rs.getInt(7), rs.getString(8), rs.getInt(9)));
            }

        } catch (SQLException ex) {
            System.err.println("Error" + ex);
        }

        //Set cell value factory to tableview.
        //NB.PropertyValue Factory must be the same with the one set in model class.
        idC.setCellValueFactory(new PropertyValueFactory<>("id"));
        nomC.setCellValueFactory(new PropertyValueFactory<>("nom"));
        prenomC.setCellValueFactory(new PropertyValueFactory<>("prenom"));
        sujetC.setCellValueFactory(new PropertyValueFactory<>("sujet"));
        fonctionnalitesC.setCellValueFactory(new PropertyValueFactory<>("fonctionnalites"));
        technologiesC.setCellValueFactory(new PropertyValueFactory<>("technologies"));
        etatC.setCellValueFactory(new PropertyValueFactory<>("etat"));
        etablissementC.setCellValueFactory(new PropertyValueFactory<>("etablissement"));
        prenomC.setSortType(TableColumn.SortType.DESCENDING);
        nomC.setSortType(TableColumn.SortType.DESCENDING);
        tableFiches.setItems(null);
        tableFiches.setItems(data);

//        sortedData.comparatorProperty().bind(tableFiches.comparatorProperty());
//        tableFiches.setItems(sortedData);
    }

    @FXML
    public void afficherArchives() {

        try {
            btnDesarchiver.setDisable(false);
            Connection conn = dc.Connect();
            data = FXCollections.observableArrayList();
            // Execute query and store result in a resultset
            ResultSet rs = conn.createStatement().executeQuery("SELECT * FROM archivesfiches group by nom,prenom");
            while (rs.next()) {
                //get string from db,whichever way 
                data.add(new fichepfe(rs.getInt(1), rs.getString(2), rs.getString(3), rs.getString(4), rs.getString(5), rs.getString(6), rs.getInt(7), rs.getString(8), rs.getInt(9)));
                delBtn.setDisable(true);

            }

        } catch (SQLException ex) {
            System.err.println("Error" + ex);
        }

        //Set cell value factory to tableview.
        //NB.PropertyValue Factory must be the same with the one set in model class.
        idC.setCellValueFactory(new PropertyValueFactory<>("id"));
        nomC.setCellValueFactory(new PropertyValueFactory<>("nom"));
        prenomC.setCellValueFactory(new PropertyValueFactory<>("prenom"));
        sujetC.setCellValueFactory(new PropertyValueFactory<>("sujet"));
        fonctionnalitesC.setCellValueFactory(new PropertyValueFactory<>("fonctionnalites"));
        technologiesC.setCellValueFactory(new PropertyValueFactory<>("technologies"));
        etatC.setCellValueFactory(new PropertyValueFactory<>("etat"));
        etablissementC.setCellValueFactory(new PropertyValueFactory<>("etablissement"));
        prenomC.setSortType(TableColumn.SortType.DESCENDING);
        nomC.setSortType(TableColumn.SortType.DESCENDING);
        tableFiches.setItems(null);
        tableFiches.setItems(data);

    }

    @FXML
    private void DeleteFiche(ActionEvent event) throws SQLException {

        Connection conn = dc.Connect();
        CrudPfe c = new CrudPfe();
        fichepfe f = new fichepfe();
        f.setNom(tableFiches.getSelectionModel().getSelectedItem().getNom());
        f.setPrenom(tableFiches.getSelectionModel().getSelectedItem().getPrenom());
        f.setSujet(tableFiches.getSelectionModel().getSelectedItem().getSujet());
        f.setFonctionnalites(tableFiches.getSelectionModel().getSelectedItem().getFonctionnalites());
        f.setTechnologies(tableFiches.getSelectionModel().getSelectedItem().getTechnologies());
        f.setEtat(tableFiches.getSelectionModel().getSelectedItem().getEtat());
        f.setEtablissement(tableFiches.getSelectionModel().getSelectedItem().getEtablissement());
        f.setIduser(1);
        // c.deleteFiche(tableFiches.getSelectionModel().getSelectedItem().getId());
        Object selectedItem = tableFiches.getSelectionModel().getSelectedItem();
        tableFiches.getItems().remove(selectedItem);
        c.archiverFiche(f);

    }

    @FXML
    private void DesarchiverFiche(ActionEvent event) throws SQLException {

        Connection conn = dc.Connect();
        CrudPfe c = new CrudPfe();
        fichepfe f = new fichepfe();
        f.setNom(tableFiches.getSelectionModel().getSelectedItem().getNom());
        f.setPrenom(tableFiches.getSelectionModel().getSelectedItem().getPrenom());
        f.setSujet(tableFiches.getSelectionModel().getSelectedItem().getSujet());
        f.setFonctionnalites(tableFiches.getSelectionModel().getSelectedItem().getFonctionnalites());
        f.setTechnologies(tableFiches.getSelectionModel().getSelectedItem().getTechnologies());
        f.setEtat(tableFiches.getSelectionModel().getSelectedItem().getEtat());
        f.setEtablissement(tableFiches.getSelectionModel().getSelectedItem().getEtablissement());
        f.setIduser(1);
        c.deleteArchivedFiche(tableFiches.getSelectionModel().getSelectedItem().getId());
        Object selectedItem = tableFiches.getSelectionModel().getSelectedItem();
        tableFiches.getItems().remove(selectedItem);
        c.addFiche(f);

    }

    private void AddF(ActionEvent event) throws IOException {
        Parent root = FXMLLoader.load(getClass().getResource("AddFicheFXML.fxml"));

        Scene scene = new Scene(root);
        Stage stage = new Stage();
        stage.setScene(scene);
        stage.show();
    }

    @FXML
    private void closeButtonAction() {
        Platform.exit();
    }

    private void filtrerFicheList(String oldValue, String newValue) {
        ObservableList<fichepfe> filteredList = FXCollections.observableArrayList();

        CrudPfe st = new CrudPfe();

        if (filterField.getText() == null || (newValue.length() < oldValue.length()) || newValue == null) {
            filteredList.clear();
            tableFiches.setItems(st.listePFe());

        } else {

            newValue = newValue.toUpperCase();

            for (fichepfe f : tableFiches.getItems()) {
                String filterFicheNom = f.getPrenom();
                String filterFichePren = f.getNom();
                if (filterFichePren.toUpperCase().contains(newValue) || (filterFicheNom.toUpperCase().contains(newValue))) {
                    filteredList.add(f);
                }
                tableFiches.setItems(filteredList);

            }

        }

    }

  

}

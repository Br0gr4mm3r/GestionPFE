/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package pfeXML;

import com.itextpdf.text.DocumentException;
import java.io.IOException;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.application.Application;
import javafx.stage.Stage;

/**
 *
 * @author Talel
 */
public class Main extends Application {

    @Override
    public void start(Stage primaryStage) throws IOException, DocumentException {

      
        Parent root = FXMLLoader.load(getClass().getResource("ListeFiches.fxml"));

        Scene scene = new Scene(root);
        Stage stage = new Stage();
        stage.setScene(scene);
        stage.show();

    }

    public static void main(String[] args) throws DocumentException, IOException {
        launch(args);

    }

}

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package pfeXML;

import Edu.esprit.Entities.fichepfe;
import com.itextpdf.text.BaseColor;
import com.itextpdf.text.Document;
import com.itextpdf.text.DocumentException;
import com.itextpdf.text.FontFactory;
import com.itextpdf.text.Image;
import com.itextpdf.text.Paragraph;
import com.itextpdf.text.Rectangle;
import com.itextpdf.text.pdf.AcroFields;
import com.itextpdf.text.pdf.PdfPTable;
import com.itextpdf.text.pdf.PdfReader;
import com.itextpdf.text.pdf.PdfStamper;
import com.itextpdf.text.pdf.PdfWriter;
import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileOutputStream;
import service.CrudPfe;
import java.io.IOException;
import java.net.URL;
import java.sql.SQLException;
import java.util.Date;
import java.util.ResourceBundle;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Parent;
import javafx.scene.control.Alert;
import javafx.scene.control.Alert.AlertType;
import javafx.scene.control.Button;
import javafx.scene.control.TextArea;
import javafx.stage.Stage;
import javafx.scene.control.TextField;

/**
 * FXML Controller class
 *
 * @author Talel
 */
public class AddFicheFXMLController implements Initializable {

    // Find your Account Sid and Token at twilio.com/user/account
    /**
     *
     */
    public static final String ACCOUNT_SID = "AC5298b509a85cb99abbb36d32fdd2b1f4";
    public static final String AUTH_TOKEN = "e9e03481b64dafaf2f981f8de146c525";

    @FXML
    private TextField nom;
    @FXML
    private TextField prenom;
    @FXML
    private Button addBtn;

    private Stage stage;
    @FXML
    private TextField sujet;
    @FXML
    private TextArea fonctionnalites;
    @FXML
    private TextField technologies;

    @FXML
    private TextField etablissement;

    //public String DEST = "./";
    //public String DEST = "./FichePFE.pdf";
    /**
     *
     */
    String DEST = "./Pdfs/";

    @FXML
    private Button closeBtn;

    /**
     * Initializes the controller class.
     *
     * @param url
     * @param rb
     */
    @Override
    public void initialize(URL url, ResourceBundle rb) {
        //TODO
    }

    @FXML
    @SuppressWarnings("empty-statement")
    private void addFiche(ActionEvent event) throws IOException, DocumentException {
        CrudPfe c = new CrudPfe();
        fichepfe f = new fichepfe();

        f.setNom(nom.getText());
        f.setPrenom(prenom.getText());
        f.setSujet(sujet.getText());
        f.setFonctionnalites(fonctionnalites.getText());
        f.setTechnologies(technologies.getText());
        //f.setEtat(Integer.valueOf(etat.getText()));
        f.setEtablissement(etablissement.getText());
        f.setIduser(1);
        //f.setSujet(Integer.valueOf(age.getText()));

        try {

            if (nom.getText().length() == 0) {
                Alert alert = new Alert(AlertType.INFORMATION);
                alert.setTitle("Information Dialog");
                alert.setHeaderText("Champ Vide");
                alert.setContentText("Le champ Nom est vide");

                alert.showAndWait();
            } else if (prenom.getText().length() == 0) {
                Alert alert = new Alert(AlertType.INFORMATION);
                alert.setTitle("Information Dialog");
                alert.setHeaderText("Champ Vide");
                alert.setContentText("Le champ Prenom est vide");

                alert.showAndWait();
            } else if (sujet.getText().length() == 0) {
                Alert alert = new Alert(AlertType.INFORMATION);
                alert.setTitle("Information Dialog");
                alert.setHeaderText("Champ Vide");
                alert.setContentText("Le champ sujet est vide");

                alert.showAndWait();
            } else if (fonctionnalites.getText().length() == 0) {
                Alert alert = new Alert(AlertType.INFORMATION);
                alert.setTitle("Information Dialog");
                alert.setHeaderText("Champ Vide");
                alert.setContentText("Le champ Fonctionnalites est vide");

                alert.showAndWait();
            } else if (technologies.getText().length() == 0) {
                Alert alert = new Alert(AlertType.INFORMATION);
                alert.setTitle("Information Dialog");
                alert.setHeaderText("Champ Vide");
                alert.setContentText("Le champ Technologies est vide");

                alert.showAndWait();
            } else if (etablissement.getText().length() == 0) {
                Alert alert = new Alert(AlertType.INFORMATION);
                alert.setTitle("Information Dialog");
                alert.setHeaderText("Champ Vide");
                alert.setContentText("Le champ Etablissement est vide");

                alert.showAndWait();
            } else {
                // System.out.println();

                Email m = new Email();
                Email.send(nom.getText(), prenom.getText(), sujet.getText(), fonctionnalites.getText(), technologies.getText(), etablissement.getText());
                CrudPfe.addFiche(f);

                File file = new File(DEST + capitalize(nom.getText()) + capitalize(prenom.getText()) + ".pdf");
                file.getParentFile().mkdirs();
                createPdf(DEST + capitalize(nom.getText()) + capitalize(prenom.getText()) + ".pdf");

//                Twilio.init(ACCOUNT_SID, AUTH_TOKEN);
//                Message message = Message
//                        .creator(new PhoneNumber("+21622591447"), new PhoneNumber("+18082013450"),
//                                "Nom: " + nom.getText() + "\n Prenom: " + prenom.getText() + "\n Fonctionnalites: " + fonctionnalites.getText() + "\n Technologies: " + technologies.getText() + "\n Etablissement: " + etablissement.getText() + "")
//                        .create();
//                System.out.println(message.getSid());
                FXMLLoader loader = new FXMLLoader(getClass().getResource("DetailFicheFXML.fxml"));

                Parent root = loader.load();

                DetailFicheFXMLController ficheController = loader.getController();
                ficheController.setNomLabel(nom.getText());
                ficheController.setPrenomLabel(prenom.getText());
                ficheController.setSujetLabel(sujet.getText());
                ficheController.setFonctionnalitesLabel(fonctionnalites.getText());
                ficheController.setTechnologiesLabel(technologies.getText());
                // ficheController.setEtatLabel(etat.getText());
                ficheController.setEtablissementLabel(etablissement.getText());

                nom.getScene().setRoot(root);
            }
        } catch (SQLException ex) {
            System.out.println(ex);
        }

    }

    /**
     *
     * @param filename
     * @throws DocumentException
     * @throws IOException
     */
    public void createPdf(String filename) throws DocumentException, IOException {
        PdfReader reader = new PdfReader(createForm());
        PdfStamper stamper = new PdfStamper(reader, new FileOutputStream(filename));
        AcroFields form = stamper.getAcroFields();
        stamper.setFormFlattening(true);
        stamper.close();
    }

    private String capitalize(final String line) {
        return Character.toUpperCase(line.charAt(0)) + line.substring(1);
    }

    public byte[] createForm() throws DocumentException, IOException {
        ByteArrayOutputStream baos = new ByteArrayOutputStream();
        Document document = new Document();
        PdfWriter writer = PdfWriter.getInstance(document, baos);
        document.open();
        Image image = Image.getInstance("esprit.png");
        image.scaleToFit(150, 230);
        document.add(image);
        document.add(new Paragraph("Bonjour " + nom.getText() + " " + prenom.getText() + " voici votre fiche : ", FontFactory.getFont(FontFactory.TIMES_BOLD, 18, BaseColor.RED)));
        document.add(new Paragraph(new Date().toString()));
        document.add(new Paragraph("----------------------------------------------------------------------------------\n\n\n"));
        document.addTitle("Votre Fiche Pfe");
        PdfPTable table = new PdfPTable(2);
        table.addCell("Nom :");
        table.addCell(capitalize((nom.getText())));
        table.addCell("Prénom :");
        table.addCell(capitalize(prenom.getText()));
        table.addCell("Sujet :");
        table.addCell(capitalize(sujet.getText()));
        table.addCell("Fonctionnalites :");
        table.addCell(fonctionnalites.getText());
        table.addCell("Technologies :");
        table.addCell(technologies.getText());
        table.addCell("Etablissement :");
        table.addCell(capitalize(etablissement.getText()));
        document.add(table);

        Rectangle rect = new Rectangle(36, 720, 144, 806);
        com.itextpdf.text.pdf.TextField tf = new com.itextpdf.text.pdf.TextField(writer, rect, "text");
        tf.setOptions(com.itextpdf.text.pdf.TextField.MULTILINE);
        writer.addAnnotation(tf.getTextField());
        document.close();
        return baos.toByteArray();
    }

    @FXML
    private void closeButtonAction() {
        // get a handle to the stage
        Stage stage = (Stage) closeBtn.getScene().getWindow();
        // do what you have to do
        stage.close();
    }

}

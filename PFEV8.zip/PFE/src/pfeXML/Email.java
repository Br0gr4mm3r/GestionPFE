package pfeXML;


import javax.mail.*;
import javax.mail.internet.InternetAddress;
import javax.mail.internet.MimeMessage;
import java.util.Properties;


public class Email {

    public static void send(String nom,String prenom , String sujet,String fonc,String tech,String etab) {

        final String username = "w7.cosmetic@gmail.com";
        final String password = "Motdepasse@@";

        Properties props = new Properties();
        props.put("mail.smtp.host", "smtp.gmail.com");
        props.put("mail.smtp.socketFactory.port", "465");
        props.put("mail.smtp.socketFactory.class",
                "javax.net.ssl.SSLSocketFactory");
        props.put("mail.smtp.auth", "true");
        props.put("mail.smtp.port", "465");

        Session session = Session.getDefaultInstance(props,
                new javax.mail.Authenticator() {
                    @Override
                    protected PasswordAuthentication getPasswordAuthentication() {
                        return new PasswordAuthentication(username,password);
                    }
                });

        try {

            
            Message message = new MimeMessage(session);
            message.setFrom(new InternetAddress("w7.cosmetic@gmail.com"));
            message.setRecipients(Message.RecipientType.TO,
                    InternetAddress.parse("talel.torkhani@esprit.tn"));
            message.setSubject("Fiche Pfe");
            message.setText("Bonjour "+nom+" "+prenom+"," + "\nSujet :"+sujet+"\nFonctionnalites :"+fonc+"\nTechnologies :"+tech+"\nEtablissement :"+etab);

            Transport.send(message);

            System.out.println("Mail sent succesfully!");

        } catch (MessagingException e) {
            throw new RuntimeException(e);
        }
    }
}
